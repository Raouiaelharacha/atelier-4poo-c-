#include "complexee.h"
int complexe::z=0;
void complexe::affi(){
   cout<<endl<<"le nbre des objets crees sont"<<z;
}
complexe::complexe(int x,int y)// provoque lors creat objet
{
	rel= new int;
	img= new int;
	 *rel = x;
	 *img = y;
	     z++;
	
	
}
complexe::complexe(){
	//constr sans parametres pour les objets qui ont pas param comme c3
	rel=new int;
	img=new int;//pour ne pas tomber dans erreur destr peut pas supp qlqs choses vide comme c3 il faut allouer memoire
	z++;
	
}

complexe::~complexe(){
	cout<<endl<<"appel du destrecteur"; //piur verifier qu'ona fait appel au destr il est convoque lors creation d'1objet lorsque appel..est affich dest et supp 
	//espace memoire pour rel et img
	
	delete rel;
	delete img;
	
}
void complexe::afficher()
{
	cout<<endl<<*rel<<"+i"<<*img; 	// on a pas fait param ds la fct donc pas la peine de faire c.rel et c.img
	
	
} 
float complexe::module()
{
	return (float)sqrt(pow(*rel,2)+pow(*img,2));
	
}
complexe somme(const complexe& A , const complexe& B){
	complexe c(*(A.rel)+*(B.rel),*(A.img)+*(B.img));//complexe c(1,2) c.rel=1 et c.img=2 c. cest pour acceder au para de class
	return c;
	 	
}
void complexe::test(){
	
	complexe c;//create new object
	
}

ostream& operator <<(ostream& o, const complexe& c){//o est cout et c est objet � afficher
o << *(c.rel)<<"+i"<<*(c.img);

}

istream& operator >>(istream& i ,complexe& c){//c est objet i est cin

	int a,b; //allocation deja fait dans constr sans parametres
	cout<<endl<<"entrer la valeur de rel";
	i>>a;
	cout<<endl<<"entrer la valeur de img";
	i>>b;
	*(c.rel)=a;
	*(c.img)=b;
	return i;

	
}
complexe& complexe::operator=(const complexe& c){//affectation
	
	*rel=*(c.rel);
	*img=*(c.img);
	return *this;//this pointe sur objet actuel qui est rel et img qui prend les val respect c.rel  c.img
	
	
}
 complexe& complexe::operator+(const complexe& c)//type de return complexe pour sommer 2 objets
 {
	(*rel)+=*(c.rel);
	(*img)+=*(c.img);
	return *this;	 	
 }
 complexe&  complexe::operator-(const complexe& c){
 	
 	(*rel)-=*(c.rel);//rel et img cad c1(rel, img) ces parametre d'objet qu'on fait avant la fct ex:c1.fct(c)
	(*img)-=*(c.img);
	return *this;	 
 		
 }
 /*complexe& complexe::operator++(){
 	// pour ex: ++c1
 	complexe c;
 	c=*this;
 	(*rel)++;
	(*img)++;
	return c;
	//pour faire incremente puis affecter ex: c1++:
	//(*rel)++;
	//(*img)++;
	//return *this;
		
 	
 }*/
 int complexe::operator==(const complexe c){ 	
 	if(rel == c.rel && img == c.img)//c.img cad img d'objet c et c.rel cad d'objet c et le c cest ce lui qui est entre ()
 		return 1;
 	return 0;
 	 
 }

main(){

 complexe c1(1,2),c2(3,4),c3,c4,c5;

c1.afficher();
c3=c1+c2;
cout<<endl<<c3;
c4=c3-c2;
cout<<endl<<c4;// il faut surcharger << car cout ne sait pas afficher un objet de type class 
// il sait afficher que les type int ,float...


complexe::affi();//on utilise complexe:: car la fct static ne depends pas d'objet il depend de class


}


