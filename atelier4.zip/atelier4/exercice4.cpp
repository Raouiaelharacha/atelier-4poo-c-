#include <iostream>
#include <list>
using namespace std;
int main()
{
    list<string> maliste;   
    string n;
    int i;
    cout<<"inserez le nom, le prenom et l'age de chaque personne et tapez stop quand vous voukez arreter :"<<endl;
    for (i = 0;; i++) // si on ajoute la condition d"arret dans boucle for ex i<=5 la boucle va se repeter que 5 fois 
    {
    cin>>n; 
    if(n=="arreter")// on fait pas la condition dans boucle for on arrete a inserer lors n==arreter
    {
        break; // pour sortir du boucle for  
    }
    maliste.push_back(n); // else
    }
    list<string>::iterator it;  
    maliste.sort();     
    it=maliste.begin();
    cout<<"votre liste  est : ";
    for (it;it!=maliste.end();it++)  
    {
            cout<<*it<<"  ";
    }
}
