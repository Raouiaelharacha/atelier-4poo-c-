#include "complexe.h"
main(){

 complexe c1(1,2),c2(3,4),c3,c4,c5;

c1.afficher();
c3=c1+c2;
cout<<endl<<c3;
c4=c3-c2;
cout<<endl<<c4;


complexe::affi();//on utilise complexe:: car la fct static ne depends pas d'objet il depend de class


}
